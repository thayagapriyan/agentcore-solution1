export const handler = async () => ({ greeting: "hi from lambda" });
